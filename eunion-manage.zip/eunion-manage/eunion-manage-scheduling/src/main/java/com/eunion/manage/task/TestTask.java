package com.eunion.manage.task;

import com.eunion.manage.websoket.SystemWebSocketHandler;
import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;

import javax.annotation.Resource;

/**
 * Created by ys on 2016/7/12.
 */
@Component
public class TestTask {

    private Logger logger = Logger.getLogger(TestTask.class);
    private static int count=0;
    @Resource
    private SystemWebSocketHandler systemWebSocketHandler;

    @Scheduled(cron = "0 0/1 * * * *")
    public void testWebSocket(){
        logger.error("webSocket task.....................");
        systemWebSocketHandler.sendMessageToUsers(new TextMessage("231321365465435"));
    }
}
