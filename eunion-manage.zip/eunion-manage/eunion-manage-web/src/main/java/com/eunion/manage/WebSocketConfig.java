package com.eunion.manage;

import com.eunion.manage.websoket.SystemWebSocketHandler;
import com.eunion.manage.websoket.WebSocketHandshakeInterceptor;
import com.eunion.manage.websoket.WebSocketUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.socket.config.annotation.*;

/**
 * Created by ys on 2016/7/9.
 */
@Configuration
@EnableWebMvc
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    @Autowired
    public SystemWebSocketHandler systemWebSocketHandler;

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        System.out.println("加载websocket 配置");
        registry.addHandler(systemWebSocketHandler,"/echo").addInterceptors(new WebSocketHandshakeInterceptor()).setAllowedOrigins("*"); //支持websocket 的访问链接
        registry.addHandler(systemWebSocketHandler,"/sockjs/echo").addInterceptors(new WebSocketHandshakeInterceptor()).setAllowedOrigins("*").withSockJS(); //不支持websocket的访问链接
    }

    @Bean
    public SystemWebSocketHandler systemWebSocketHandler(){
        return new SystemWebSocketHandler();
    }

    @Bean
    public WebSocketHandshakeInterceptor webSocketHandshakeInterceptor(){
        return new WebSocketHandshakeInterceptor();
    }


}
