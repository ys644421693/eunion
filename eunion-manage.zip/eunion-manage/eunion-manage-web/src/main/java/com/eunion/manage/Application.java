package com.eunion.manage;

import com.eunion.manage.service.UserService;
import com.eunion.manage.entity.User;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

/**
 * Created by ys on 2016/7/3.
 */
@SpringBootApplication
@EnableScheduling

public class Application {

    @SuppressWarnings("unchecked")
    public static void main(String[] args) {
        SpringApplication app=new SpringApplication(Application.class);
        Appctx.ctx=app.run(args);
        //将密码加密 必须保证数据库s_user中有id为1的用户//code14
        UserService userService = (UserService) Appctx.ctx.getBean("userService");
        User su= userService.findUserById(1);
        BCryptPasswordEncoder bc=new BCryptPasswordEncoder(4);
        su.setPassword(bc.encode("111111"));
        userService.update(su);

    }
}
