package com.eunion.manage.app.Exception;

/**
 * Created by ys on 2016/7/7.
 */
public class UnifyException extends Exception {

    public UnifyException(String message) {
        super(message);
    }
}
