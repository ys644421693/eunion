package com.eunion.manage.service;

import com.eunion.manage.entity.Resource;
import com.eunion.manage.entity.Role;

import java.util.List;

/**
 * Created by ys on 2016/7/6.
 */
public interface ResourceService {

    List<Resource> getByRole(Role role);
}
