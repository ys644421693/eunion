package com.eunion.manage.service;

import com.eunion.manage.entity.User;

/**
 * Created by ys on 2016/7/6.
 */
public interface UserService {
    User findUserByUserEmail(String userEmail);

    void update(User su);

    User findUserById(int i);
}
