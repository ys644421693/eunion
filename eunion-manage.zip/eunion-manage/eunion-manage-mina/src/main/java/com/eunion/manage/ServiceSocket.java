package com.eunion.manage;

import org.apache.mina.core.service.IoAcceptor;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.textline.LineDelimiter;
import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.Charset;

/**
 * Created by ys on 2016/7/16.
 */
public class ServiceSocket {

    public void configureSocket() throws IOException {
        //1.编写ioservice

        IoAcceptor acceptor = new NioSocketAcceptor();

        acceptor.getSessionConfig().setReadBufferSize(2048);

        acceptor.getSessionConfig().setIdleTime(IdleStatus.BOTH_IDLE, 10);//读写通道在10秒内无任何操作进入空闲状态

        //2.编写过滤器,

        //通过TextLineCodeFactory编解码工厂对字符串进行编解码处理

        acceptor.getFilterChain().addLast("codec", new ProtocolCodecFilter(new TextLineCodecFactory(Charset.forName("UTF-8"), LineDelimiter.WINDOWS.getValue(), LineDelimiter.WINDOWS.getValue())));//以换行符为标识的数据
        //3.注册iohandler到ioservice

        acceptor.setHandler(new MyServerIoHandler());

        //4绑定套接字

        acceptor.bind(new InetSocketAddress(1000));
    }
}
