package com.eunion.manage;

import java.io.IOException;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException {
        System.out.println( "Hello World!" );
        ServiceSocket serviceSocket = new ServiceSocket();
        serviceSocket.configureSocket();
    }
}
