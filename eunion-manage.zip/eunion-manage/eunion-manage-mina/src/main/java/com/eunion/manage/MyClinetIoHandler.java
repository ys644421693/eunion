package com.eunion.manage;

import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IoSession;

/**
 * Created by ys on 2016/7/16.
 */
public class MyClinetIoHandler extends IoHandlerAdapter {

    private final String values;

    public MyClinetIoHandler(String values) {
        this.values = values;
    }

    @Override
    public void sessionOpened(IoSession session) throws Exception {
        // TODO Auto-generated method stub
        session.write(values);
    }

}

