package com.eunion.manage.repository;

import com.eunion.manage.entity.Resource;
import com.eunion.manage.entity.Role;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by ys on 2016/7/6.
 */
public interface ResourceRepository extends CrudRepository<Resource,Long> {

    List<Resource> findAll();

    List<Resource> findByRole(Role role);
}
