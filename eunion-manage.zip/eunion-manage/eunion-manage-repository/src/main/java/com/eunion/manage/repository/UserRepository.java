package com.eunion.manage.repository;

import com.eunion.manage.entity.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ys on 2016/7/6.
 */
public interface UserRepository extends CrudRepository<User,Long> {

    @Query("select u from User u where u.userEmail=?1 and u.password=?2")
    User login(String userEmail, String password);

    User findByUserEmailAndPassword(String userEmail, String password);

    User findUserByUserEmail(String userEmail);

    User findUserById(int i);
}
