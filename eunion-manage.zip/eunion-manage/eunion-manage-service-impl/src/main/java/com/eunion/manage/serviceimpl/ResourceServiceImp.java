package com.eunion.manage.serviceimpl;

import com.eunion.manage.repository.ResourceRepository;
import com.eunion.manage.service.ResourceService;
import com.eunion.manage.entity.Resource;
import com.eunion.manage.entity.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by ys on 2016/7/6.
 */
@Service("resourceService")
public class ResourceServiceImp implements ResourceService {

    @Autowired
    private ResourceRepository resourceRepository;

    public List<Resource> getAll(){
        return resourceRepository.findAll();
    }

    @Override
    public List<Resource> getByRole(Role role) {
        return resourceRepository.findByRole(role);
    }
}
