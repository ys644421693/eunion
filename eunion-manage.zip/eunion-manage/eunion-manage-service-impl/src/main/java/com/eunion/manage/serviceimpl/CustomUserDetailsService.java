package com.eunion.manage.serviceimpl;

import com.eunion.manage.service.UserService;
import com.eunion.manage.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * Created by ys on 2016/7/3.
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired  //数据库服务类
    private UserService userService;


    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        //User对应数据库中的用户表，是最终存储用户和密码的表，可自定义
        //本例使用User中的email作为用户名:
        User user = userService.findUserByUserEmail(userName); //code8
        if (user == null) {
            throw new UsernameNotFoundException("UserName " + userName + " not found");
        }
        // SecurityUser实现UserDetails并将SUser的Email映射为username
        return new SecurityUser(user);

    }
}
