package com.eunion.manage.websoket;

import com.eunion.manage.WebSocketEntity;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.WebSocketSession;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ys on 2016/7/24.
 */
@Service("webSocketUserService")
public class WebSocketUserService {

    private List<WebSocketEntity> user = new ArrayList<>();

    @Cacheable(value = "webSocketEntity",keyGenerator = "wiselyKeyGenerator")
    public List<WebSocketEntity> getUserList(){
        return user;
    }

    //删除用户
    @CacheEvict(value = "webSocketEntity",keyGenerator = "wiselyKeyGenerator")
    public List<WebSocketEntity> removeUser(String id){
       for (WebSocketEntity webSocketEntity: user){
           if (webSocketEntity.getId().equals(id)){
               user.remove(webSocketEntity);
           }
       }
       return user;
    }
    //
    @CachePut(value = "webSocketEntity",keyGenerator = "wiselyKeyGenerator")
    public List<WebSocketEntity> addUser(WebSocketEntity webSocketSession){
        user.add(webSocketSession);
        return user;
    }
}
