package com.eunion.manage.serviceimpl;

import com.eunion.manage.repository.UserRepository;
import com.eunion.manage.service.UserService;
import com.eunion.manage.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by ys on 2016/7/6.
 */
@Service("userService")
public class UserServiceImp implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public User findUserByUserEmail(String userEmail) {
        return userRepository.findUserByUserEmail(userEmail);
    }

    @Override
    public void update(User su) {
        userRepository.save(su);
    }

    @Override
    public User findUserById(int i) {
        return userRepository.findUserById(i);
    }
}
