package com.eunion.manage.serviceimpl;

import com.eunion.manage.service.UserService;
import com.eunion.manage.entity.Resource;
import com.eunion.manage.entity.Role;
import com.eunion.manage.entity.User;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.FilterInvocation;

import java.util.Collection;

/**
 * 访问决策器，决定某个用户具有的角色，是否有足够的权限去访问某个资源 ;做最终的访问控制决定
 * Created by ys on 2016/7/3.
 */
public class AppAccessDescisionManager implements AccessDecisionManager {

    @Autowired
    private UserService userService;

    private static Logger log = Logger.getLogger(AppAccessDescisionManager.class);
    @Override
    public void decide(Authentication authentication, Object object, Collection<ConfigAttribute> collection) throws AccessDeniedException, InsufficientAuthenticationException {
        log.info("AppAccessDescisionManager 验证用户是否具有访问资源的权限");
         // object 是一个URL，被用户请求的url。
        if (null == collection)
            return;

        String url = ((FilterInvocation) object).getRequestUrl();
        User user =null;
        try{
            user = (User) authentication.getPrincipal();
        }catch (ClassCastException e){
            return ;
        }


        //访问数据库
        for (Role role :user.getRoles()) {
            for (Resource resource:role.getResource()){
                if(resource.getUrl().equals(url)){
                    return ;
                }
            }
        }
        //没有权限
       throw new AccessDeniedException("没有权限访问！");
    }

    @Override
    public boolean supports(ConfigAttribute configAttribute) {
        return true;
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return true;
    }


}
