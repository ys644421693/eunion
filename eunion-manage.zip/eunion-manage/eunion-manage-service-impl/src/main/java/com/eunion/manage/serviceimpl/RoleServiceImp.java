package com.eunion.manage.serviceimpl;

import com.eunion.manage.repository.RoleRepository;
import com.eunion.manage.service.RoleService;
import com.eunion.manage.entity.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by ys on 2016/7/6.
 */
@Service("roleService")
public class RoleServiceImp implements RoleService {

    @Autowired
    private RoleRepository roleRepository;

    @Override
    public List<Role> getAll() {
        return roleRepository.findAll() ;
    }
}
