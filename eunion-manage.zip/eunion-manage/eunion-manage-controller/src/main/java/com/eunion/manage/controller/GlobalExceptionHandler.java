package com.eunion.manage.controller;

import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by ys on 2016/7/7.
 */
//@RestController
public class GlobalExceptionHandler implements ErrorController {

    private static final String ERROR_PATH = "/error";

    @RequestMapping(value=ERROR_PATH)
    public Object handleError(Exception exception){

        System.err.println(exception.getMessage());
        Map<String,String> map = new HashMap<String,String>();
        map.put("name","zhangsan");
        return map;
    }

    @Override
    public String getErrorPath() {
        return ERROR_PATH;
    }
}
