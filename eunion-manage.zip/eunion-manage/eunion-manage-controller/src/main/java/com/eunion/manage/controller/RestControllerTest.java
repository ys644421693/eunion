package com.eunion.manage.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by ys on 2016/7/3.
 */
@RestController("/")
public class RestControllerTest {

    @RequestMapping("/userName")
    public Object test(){
        Map<String,String> map = new HashMap<String,String>();
        map.put("name","zhangSan");
        map.put("password","123456");
        return map;
    }

    @RequestMapping("/data")
    public Object data(){
        Map<String,String> map = new HashMap<String,String>();
        map.put("name","data");
        map.put("password","data");
        return map;
    }

    @RequestMapping("/word")
    public Object word(){
        Map<String,String> map = new HashMap<String,String>();
        map.put("name","hell,word");
        map.put("password","123456");
        return map;
    }
}
