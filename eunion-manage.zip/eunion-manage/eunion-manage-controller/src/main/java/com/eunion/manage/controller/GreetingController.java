package com.eunion.manage.controller;

import com.eunion.manage.Address;
import com.eunion.manage.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;

/**
 * Created by ys on 2016/7/3.
 */
@Controller
@RequestMapping("/")
public class GreetingController {

    @Autowired
    DemoService demoService;

    @RequestMapping("/home")
    public String home() {
        Address address =demoService.findAddress(1l,"anhui","hefei");
        System.out.println("我这里没执行查询");
        System.err.println("home-----------------------------");
        System.out.println("address:"+"/"+address.getProvince()+"/"+address.getCity());
        return "home";
    }

    @RequestMapping("/hello")
    public String hello() {
        System.err.println("hell-----------------------------");
        SecurityContext ctx = SecurityContextHolder.getContext();
        Authentication auth = ctx.getAuthentication();
        if (auth.getPrincipal() instanceof UserDetails) {
           /* SUser user = (SUser) auth.getPrincipal();
            System.out.println(user.getEmail());*/
        }
        //本段代码演示如何获取登录的用户资料

        return "hello";
    }

    @RequestMapping("/")
    public String root() throws Exception {
        System.err.println("index-----------------------------");
        demoService.findAddress(1l,"anhui","hefei");
        System.out.println("若下面没出现“无缓存的时候调用”字样且能打印出数据表示测试成功");
        //如不进行此项配置，从login登录成功后，会提示找不网页
      //  throw  new Exception("1234651321325");
        return "index";
    }

    @RequestMapping("/login")
    public String login() {
        System.err.println("login-----------------------------");
        return "login";
    }

    @RequestMapping("/login?error")
    public String loginError() {
        System.err.println("login-----------------------------");
        return "index";
    }

    @RequestMapping("/test")
    public String test() {
        System.out.println("test-----------------------------");
        return "test";
    }

}

