package com.eunion.manage.entity;

import javax.persistence.*;
import java.util.Set;

/**
 * Created by ys on 2016/7/5.
 */
@Entity
@Table(name = "t_role")
public class Role {
    private int id;
    private String roleName;
    private String roleDescription;
    private String roleType;
    private Set<User> users;
    private Set<Resource> resource;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "role_id", unique = true, nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    @Column(name = "role_name", nullable = false)
    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
    @Column(name = "role_description")
    public String getRoleDescription() {
        return roleDescription;
    }

    public void setRoleDescription(String roleDescription) {
        this.roleDescription = roleDescription;
    }
    @Column(name = "role_type")
    public String getRoleType() {
        return roleType;
    }

    public void setRoleType(String roleType) {
        this.roleType = roleType;
    }

    @ManyToMany(mappedBy="roles",cascade=CascadeType.ALL)
    public Set<User> getUsers() {
        return users;
    }
    public void setUsers(Set<User> users) {
        this.users = users;
    }

    @ManyToMany(cascade=CascadeType.ALL,fetch = FetchType.EAGER)
    @JoinTable(name="t_role_resource",joinColumns=@JoinColumn(name="role_id"),inverseJoinColumns=@JoinColumn(name="resource_id"))
    public Set<Resource> getResource() {
        return resource;
    }

    public void setResource(Set<Resource> resource) {
        this.resource = resource;
    }
}
