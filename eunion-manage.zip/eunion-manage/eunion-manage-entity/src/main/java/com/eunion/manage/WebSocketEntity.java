package com.eunion.manage;

import com.eunion.manage.entity.User;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketSession;

import javax.persistence.Entity;

/**
 * Created by ys on 2016/7/24.
 */

public class WebSocketEntity {

    public String id;
    private User user;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
