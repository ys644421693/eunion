/**
 * Created by yangshuo on 15/11/23.
 */

var app = angular.module('app',['ngRoute','ngResource','ngFileUpload']);

